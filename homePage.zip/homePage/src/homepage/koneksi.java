package homepage;

import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class koneksi {
 
    Connection con;
    Statement st;
    ResultSet rs;

    public Connection setConnection() {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/furever_home", "root", "");
            st = con.createStatement();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Connection Failed " + e);
            // Set con to null if connection fails
            con = null;
        }

        return con; // Return null if connection failed
    }
}



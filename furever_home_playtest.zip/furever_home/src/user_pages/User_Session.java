/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package user_pages;
import koneksi.*;
import java.awt.*;
import java.sql.*;
import javax.swing.ImageIcon;

/**
 *
 * @author reggie
 */
public class User_Session {
    
    private static String user_username;
    private static String user_fullname;
    private static String user_age;
    private static String user_occupation;
    private static String user_salary;
    private static String user_petHistory;
    private static String user_phoneNumber;
    private static ImageIcon user_picture;
    
    public static void endSession()
    {
        user_username = null;
        user_fullname = null;
        user_age = null;
        user_occupation = null;
        user_salary = null;
        user_petHistory = null;
        user_phoneNumber = null;
        user_picture = null;
    }
    
    public static void currSessionUser(String username)
    {
        setUsername(username);
        getFullInfo();
    }
    
    public static void setUsername(String username)
    {
        user_username = username;
    }
    
    public static String getUsername()
    {
        return user_username;
    }
    
    private static void getFullInfo()
    {
        try {
            koneksi kon = new koneksi();
            Connection conn = kon.setConnection();
            String search_user = "select * from tb_user where user_username = '" + user_username + "'";
            Statement search_stm = conn.createStatement();
            ResultSet search_rs = search_stm.executeQuery(search_user);
            
            while (search_rs.next())
            {
                user_fullname = search_rs.getString("user_fullname"); 
                user_age = search_rs.getString("user_age");
                user_occupation = search_rs.getString("user_occupation");
                user_salary = search_rs.getString("user_salary");
                user_petHistory = search_rs.getString("user_petHistory");
                user_phoneNumber = search_rs.getString("user_phoneNumber");
                
                byte[] img = search_rs.getBytes("user_profilePicture");
                ImageIcon image = new ImageIcon(img);
                Image selected_pfp = image.getImage();

                user_picture = new ImageIcon(selected_pfp);
            }
            
        } catch (Exception ex) {
            System.out.println("Unable to collect full account info: "+ex);
        }
        
    }
}

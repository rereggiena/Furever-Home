package user_pages;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author nadia
 */

import admin_pages.Admin_AddAnimal;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import javax.swing.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import koneksi.koneksi;
import user_pages.User_Session;

public class User_Account_Info extends javax.swing.JFrame {

    koneksi kon = new koneksi();
    String path_for_insert = null;
    /**
     * Creates new form newPopUp
     */
    public User_Account_Info() {
        initComponents();
        setIconImage();
        
        displayUserData(User_Session.getUsername());
        displayAnimalData(User_Session.getUsername());
        submit_button.setVisible(false);
    }
    
    private void setIconImage() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images/original_icon_file.jpeg")));
    } 

   private void displayUserData(String username) {
        try {
            String select_rows = "select user_fullname, user_profilePicture from tb_user where user_username = '" + username + "'";
            
            Connection connection = kon.setConnection();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select_rows);
            
            String fullname = null;
            ImageIcon final_image = null;
            
            while (rs.next())
            {
                fullname = rs.getString(1);
                
                byte[] img = rs.getBytes(2);
                if (rs.wasNull())
                {
                    ImageIcon image_icon = new ImageIcon(Toolkit.getDefaultToolkit().
                                            getImage(getClass().getResource("/images/default_pfp.jpg")));
                    Image default_pfp = image_icon.getImage();
                    Image scaled_default_pfp = default_pfp.getScaledInstance(135, 135, Image.SCALE_SMOOTH);
                    ImageIcon final_scaled_default_pfp = new ImageIcon(scaled_default_pfp);
                    
                    user_picture.setIcon(final_scaled_default_pfp);
                }
                
                else
                {   
                    ImageIcon image = new ImageIcon(img);
                    Image selected_picture = image.getImage();
                    Image scaled_image = selected_picture.getScaledInstance(135, 135, Image.SCALE_SMOOTH);
                    final_image = new ImageIcon(scaled_image);  
                    
                    System.out.println("yes user picture");
                    user_picture.setIcon(final_image);
                }   
            }
            
            userid_label.setText(username);
            username_label.setText(fullname);
            
            kon.closeConnection();
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "User Display Error "+ex);
        }
    }

    private void displayAnimalData(String user_username)
    {
        try {
            Connection connection = kon.setConnection();
            String animal_select = "select animal_id, animal_name, animal_breed, "
                                + "animal_age, animal_picture, request_status from tb_application "
                                + "where user_username = '" + User_Session.getUsername() + "'";
            Statement animal_stm = connection.createStatement();
            ResultSet animal_result = animal_stm.executeQuery(animal_select);
            if (animal_result.next())
            {   
                int id = 0;
                String name = null;
                String breed = null;
                String age = null;
                String status = null;
                ImageIcon final_image = null;
                    
                id = animal_result.getInt(1);
                name = animal_result.getString(2);
                breed = animal_result.getString(3);
                age = animal_result.getString(4);

                byte[] img = animal_result.getBytes(5);
                ImageIcon image = new ImageIcon(img);
                Image selected_picture = image.getImage();
                Image scaled_image = selected_picture.getScaledInstance(135, 180, Image.SCALE_SMOOTH);

                final_image = new ImageIcon(scaled_image);

                status = animal_result.getString(6);
            
                animal_id.setText(Integer.toString(id));
                animal_name.setText(name);
                animal_breed.setText(breed);
                animal_age.setText(age);
                animal_picture.setIcon(final_image);
                request_status.setText(status);
            }
            
            else {
                animal_id.setText("");
                animal_name.setText("No Requests.");
                animal_breed.setText("");
                animal_age.setText("");
                animal_picture.setIcon(null);
                animal_picture.setText("");
                status_label.setText("");
                request_status.setText("");
            }
            
            kon.closeConnection();
            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Animal Display Error "+ex);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        username_label = new javax.swing.JLabel();
        userid_label = new javax.swing.JLabel();
        request_text = new javax.swing.JLabel();
        animal_id = new javax.swing.JLabel();
        animal_name = new javax.swing.JLabel();
        animal_breed = new javax.swing.JLabel();
        animal_age = new javax.swing.JLabel();
        close_button = new javax.swing.JButton();
        status_label = new javax.swing.JLabel();
        animal_picture = new javax.swing.JLabel();
        request_status = new javax.swing.JLabel();
        edit_picture_button = new javax.swing.JButton();
        submit_button = new javax.swing.JButton();
        user_picture = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(346, 500));
        setSize(new java.awt.Dimension(346, 500));

        jPanel1.setBackground(new java.awt.Color(255, 243, 224));
        jPanel1.setPreferredSize(new java.awt.Dimension(346, 500));
        jPanel1.setRequestFocusEnabled(false);

        jPanel2.setBackground(new java.awt.Color(109, 69, 33));
        jPanel2.setPreferredSize(new java.awt.Dimension(364, 42));

        jLabel1.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(250, 240, 230));
        jLabel1.setText("Account Information");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(83, 83, 83)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );

        username_label.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 18)); // NOI18N
        username_label.setForeground(new java.awt.Color(109, 69, 33));
        username_label.setText("User Name");

        userid_label.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 14)); // NOI18N
        userid_label.setForeground(new java.awt.Color(109, 69, 33));
        userid_label.setText("User Id");

        request_text.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 14)); // NOI18N
        request_text.setForeground(new java.awt.Color(109, 69, 33));
        request_text.setText("Requests:");

        animal_id.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 14)); // NOI18N
        animal_id.setForeground(new java.awt.Color(109, 69, 33));
        animal_id.setText("Animal Id");

        animal_name.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 18)); // NOI18N
        animal_name.setForeground(new java.awt.Color(109, 69, 33));
        animal_name.setText("Animal Name");

        animal_breed.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 18)); // NOI18N
        animal_breed.setForeground(new java.awt.Color(109, 69, 33));
        animal_breed.setText("Animal Breed");

        animal_age.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 18)); // NOI18N
        animal_age.setForeground(new java.awt.Color(109, 69, 33));
        animal_age.setText("Animal Age");

        close_button.setBackground(new java.awt.Color(109, 69, 33));
        close_button.setFont(new java.awt.Font("Advent Pro SemiExpanded", 0, 12)); // NOI18N
        close_button.setForeground(new java.awt.Color(255, 243, 224));
        close_button.setText("Close");
        close_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                close_buttonActionPerformed(evt);
            }
        });

        status_label.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 18)); // NOI18N
        status_label.setForeground(new java.awt.Color(109, 69, 33));
        status_label.setText("Status :");

        animal_picture.setForeground(new java.awt.Color(0, 0, 0));
        animal_picture.setMaximumSize(new java.awt.Dimension(135, 180));
        animal_picture.setPreferredSize(new java.awt.Dimension(135, 180));

        request_status.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 18)); // NOI18N
        request_status.setForeground(new java.awt.Color(109, 69, 33));

        edit_picture_button.setBackground(new java.awt.Color(109, 69, 33));
        edit_picture_button.setFont(new java.awt.Font("Advent Pro SemiExpanded", 1, 12)); // NOI18N
        edit_picture_button.setForeground(new java.awt.Color(255, 243, 224));
        edit_picture_button.setText("Edit Picture");
        edit_picture_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_picture_buttonActionPerformed(evt);
            }
        });

        submit_button.setBackground(new java.awt.Color(109, 69, 33));
        submit_button.setFont(new java.awt.Font("Advent Pro SemiExpanded", 0, 12)); // NOI18N
        submit_button.setForeground(new java.awt.Color(255, 243, 224));
        submit_button.setText("Submit");
        submit_button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submit_buttonActionPerformed(evt);
            }
        });

        user_picture.setMaximumSize(new java.awt.Dimension(135, 135));
        user_picture.setPreferredSize(new java.awt.Dimension(135, 135));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 346, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(animal_picture, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(request_text)
                    .addComponent(animal_name)
                    .addComponent(user_picture, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(username_label)
                    .addComponent(userid_label)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(edit_picture_button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(submit_button, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(animal_id)
                    .addComponent(animal_breed)
                    .addComponent(animal_age)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(status_label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(request_status, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(close_button)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(user_picture, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(userid_label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(username_label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(edit_picture_button)
                            .addComponent(submit_button))))
                .addGap(31, 31, 31)
                .addComponent(request_text)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(animal_name)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(animal_id)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(animal_breed)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(animal_age)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(status_label))
                    .addComponent(animal_picture, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(request_status, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(close_button)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void close_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_close_buttonActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_close_buttonActionPerformed

    private void edit_picture_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_picture_buttonActionPerformed
        // TODO add your handling code here:
        JFileChooser chooseFile = new JFileChooser();
        
        chooseFile.showOpenDialog(null);
        File photoFile = chooseFile.getSelectedFile();
        String filePath = photoFile.getAbsolutePath();
        
        try {
            BufferedImage bi = ImageIO.read(new File(filePath));
            Image img = bi.getScaledInstance(135, 135, Image.SCALE_SMOOTH);
            
            ImageIcon petPhoto = new ImageIcon(img);
            user_picture.setIcon(petPhoto);
            
            path_for_insert = filePath;
            
            submit_button.setVisible(true);
            
        } catch (IOException ex) {
            Logger.getLogger(Admin_AddAnimal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_edit_picture_buttonActionPerformed

    private void submit_buttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submit_buttonActionPerformed
        // TODO add your handling code here:
        try 
        {
            Connection conn = kon.setConnection();
            PreparedStatement ps = conn.prepareStatement("update tb_user set user_profilePicture = ?"
                                + " where user_username = '" + User_Session.getUsername() + "'");
            
            InputStream is = new FileInputStream(new File(path_for_insert));
            ps.setBlob(1, is);
            
            ps.executeUpdate();
            
            submit_button.setVisible(false);
            
            kon.closeConnection();
            
        } catch (Exception ex) {
            System.out.println("Error in changing profile picture.");
        }
        
    }//GEN-LAST:event_submit_buttonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(User_Account_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(User_Account_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(User_Account_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(User_Account_Info.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new User_Account_Info().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel animal_age;
    private javax.swing.JLabel animal_breed;
    private javax.swing.JLabel animal_id;
    private javax.swing.JLabel animal_name;
    private javax.swing.JLabel animal_picture;
    private javax.swing.JButton close_button;
    private javax.swing.JButton edit_picture_button;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel request_status;
    private javax.swing.JLabel request_text;
    private javax.swing.JLabel status_label;
    private javax.swing.JButton submit_button;
    private javax.swing.JLabel user_picture;
    private javax.swing.JLabel userid_label;
    private javax.swing.JLabel username_label;
    // End of variables declaration//GEN-END:variables
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package user_pages;

/**
 *
 * @author reggie
 */
public class User_Session {
    private static String user_username;
    
    public static void setUsername(String username)
    {
        user_username = username;
    }
    
    public static String getUsername()
    {
        return user_username;
    }
}

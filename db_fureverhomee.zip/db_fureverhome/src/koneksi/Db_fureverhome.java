
package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class Db_fureverhome {
 Connection con;
    Statement st;
    ResultSet rs;
    
    public Connection setConnection()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");  //link and database name   username  password
            con = DriverManager.getConnection("jdbc:mysql://localhost/furever_home", "root", "");
            st = con.createStatement();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Connection Failed " + e);
        }
        
        return con;
    }
    
}

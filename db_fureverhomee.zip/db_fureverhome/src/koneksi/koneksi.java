package koneksi;
import java.sql.*;
import javax.swing.JOptionPane;

public class koneksi {
 public Connection con;
    public Statement st;
    public ResultSet rs;
    
    public Connection setConnection()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");  //link and database name   username  password
            con = DriverManager.getConnection("jdbc:mysql://localhost/db_fureverhome", "root", "");
            st = con.createStatement();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Connection Failed " + e);
        }
        
        return con;
    }
    
    public void closeConnection()
    {
        try
        {
            if (con != null)
            {
                System.out.print("\nClosing Connection.\n");
            }
        }
        
        catch(Exception ex)
        {
            System.out.println("\nClose Connection Failed "+ex);
        }
    }
}   

